package br.com.alura.microservice.loja.model;

public enum CompraState {
	RECEBIDO, PEDIDO_REALIZADO, RESERVA_ENTREGA_REALIZADA
}

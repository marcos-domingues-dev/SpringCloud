package br.com.alura.microservice.loja.model;

public enum Situacao {
	PEDIDO_REALIZADO, RESERVA_PARA_ENTREGA_REALIZADA, FINALIZADA; 
}
